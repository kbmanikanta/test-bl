
var _=require("lodash");

module.exports.process=function(data, $, cb){
	var queues = global.bl.queues.getAll();
	cb();
}