
var help=require(global.bl.appRoot + "/components/blacklight/develop/widget-helper");

exports.dialog=function($){
	return help.dialog("Text field");
}




