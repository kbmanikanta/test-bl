
module.exports.makePartials = true;