exports.dialog=function($){
    var dialog={
        title: "Select Option",
        items: {
            title:{widget:"textfield"},
            value:{widget:"textfield"}
        }
    };
    return dialog;
};
