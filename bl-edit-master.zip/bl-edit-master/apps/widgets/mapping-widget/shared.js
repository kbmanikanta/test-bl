


module.exports.mappingTypes =
	{"bl:ref":"Direct reference", 
	"bl:query":"Query with filters",
	"bl:inherit-cascade":"Cascading inherit", 
	"bl:list-ancestors":"List parent pages",
	"bl:list-subtree":"List child pages",
	"bl:link":"Remap link",
	"bl:component-inherit":"Inherit from component prototype"
	};



