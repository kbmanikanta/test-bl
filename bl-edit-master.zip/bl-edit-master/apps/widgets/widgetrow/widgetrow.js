

module.exports.makePartials = true;