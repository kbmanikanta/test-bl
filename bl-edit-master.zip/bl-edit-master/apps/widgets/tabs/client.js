


module.exports={
	init:function($el){
		$el.tabs();
	}
}


