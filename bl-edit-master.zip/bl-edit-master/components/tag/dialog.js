exports.dialog=function($){
  var dialog={
    title: "Tag",
    items: {
       "jcr:title":{widget:"textfield"}
    }
  };
  return dialog;
};
